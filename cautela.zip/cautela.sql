-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 28-Fev-2025 às 18:18
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cautela`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `profissionais`
--

CREATE TABLE `profissionais` (
  `id` int(200) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `numero` varchar(200) NOT NULL,
  `posicao` text NOT NULL,
  `area` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `profissionais`
--

INSERT INTO `profissionais` (`id`, `nome`, `foto`, `numero`, `posicao`, `area`) VALUES
(97, 'Dr. Cautela (Pai)', '67bcae7328b2e1510152175_dr.-jose-cautela-pai-ntb090ishc4es57rw2g4co62vc00wjwq9um4kwkr9k.jpg', '6765', 'omd', 'a:1:{i:0;s:8:\"Gerencia\";}'),
(98, 'Dr. Cautela (Filho)', '67bcaeb6c2d9c1510153032_dr.-jose-cautela-filho-ntb08vtlj5xz63elniezi7crwen6u2e2l7cp6irq4o.jpg', '9495', 'omd', 'a:1:{i:0;s:17:\"Prostodontia Fixa\";}'),
(99, 'Dr. Duarte MourÃ£o', '67bcaeef6ec001510156941_dr.-duarte-mourao-ntazl79zcfiwnrsyxrwd6ohp3xd9wldizznawjvsw8.jpg', '9715', 'omd', 'a:2:{i:0;s:17:\"Prostodontia Fixa\";i:1;s:10:\"Endodontia\";}'),
(100, 'Dra. Ana LÃºcia Carvalho', '67bcaf2393fde1510155524_dra.-ana-lucia-carvalho-ntazlryfisb7r6yxl0u5pj9u6ejclxnmetzzgn153c.jpg', '6759', 'omd', 'a:2:{i:0;s:17:\"Prostodontia Fixa\";i:1;s:11:\"Generalista\";}'),
(101, 'Dr. Eduardo Cruz', '67bcaf7389da81523449927_dr_eduardocruz_acl-ntazl4ggrxf1oxx2e8ohh77bbrr69i2bzlougpzzew.jpg', '9033', 'omd', 'a:3:{i:0;s:17:\"Prostodontia Fixa\";i:1;s:13:\"Implantologia\";i:2;s:13:\"Cirurgia Oral\";}'),
(102, 'Dr. JoÃ£o ConceiÃ§Ã£o', '67bcafc0e1c621521413804_drjoaoconceicao-ntb08s28rtstvnk29gsh88axiv5pz9z58oqr9exatk.jpg', '1398', 'omd', 'a:3:{i:0;s:17:\"Prostodontia Fixa\";i:1;s:13:\"Implantologia\";i:2;s:13:\"Cirurgia Oral\";}'),
(103, 'Dr. Pedro Santos', '67bcb01b380471510153901_dr.-pedro-santos-ntb08oaw0hnol7pivf5yy9935bo94hk7w64tcb2vig.jpg', '1449', 'omd', 'a:4:{i:0;s:17:\"Prostodontia Fixa\";i:1;s:27:\"Ortodontia fixa e Removivel\";i:2;s:13:\"Implantologia\";i:3;s:7:\"Oclusao\";}'),
(104, 'Dra. MÂª JoÃ£o Sobreira', '67bcb0687139a1510154761_dra.-maria-joao-sobreira-ntazm0ez8amsnomn7mhstz4zivdnj7l7fzvcs4oljc.jpg', '221', 'omd', 'a:1:{i:0;s:11:\"Generalista\";}'),
(105, 'Dra. Tatiana Farinha', '67bcb0c438bf0tatianafarinha.png', '12142', 'omd', 'a:2:{i:0;s:11:\"Generalista\";i:1;s:22:\"Prostodontia Removivel\";}'),
(106, 'Dra. Filipa Franco', '67bcb10e62caafilipa_franco-p2m46frm9zpmdc7pv05ldh0qq4388ijrxnqcig5348.png', '2168', 'omd', 'a:2:{i:0;s:11:\"Generalista\";i:1;s:7:\"Oclusao\";}'),
(107, 'Dra. Margarida Ferreira', '67bcb15da79f0dramargaridaferreira.png', '13041', 'omd', 'a:1:{i:0;s:11:\"Generalista\";}'),
(108, 'Dra. Joana Vilar', '67bcb19f8d36fdrajoanavilar.png', '13408', 'omd', 'a:2:{i:0;s:11:\"Generalista\";i:1;s:13:\"Cirurgia Oral\";}'),
(109, 'Dra. Mariana Oliveira', '67bcb1e0e6c54dramarianaoliveira.png', '14599', 'omd', 'a:1:{i:0;s:11:\"Generalista\";}'),
(110, 'Dr. Sandro Pinto', '67bcb22392d5esandropinto_final.png', '15518', 'omd', 'a:1:{i:0;s:11:\"Generalista\";}'),
(111, 'Dra. Ana Monteiro', '67bcb26048c0amedica-ana-monteiro-opoxe2ql0egxlhdy3f6xzqp1beddl6f814atukslc8.png', '13054', 'omd', 'a:1:{i:0;s:10:\"Endodontia\";}'),
(112, 'Dra. Catarina Ameixa', '67bcb29421be2dracatarinaameixa-p4qj5evdmp4k3ody5x0neuay9nawm1jab9wmvhzvgo.png', '12898', 'omd', 'a:1:{i:0;s:10:\"Endodontia\";}'),
(113, 'Dra. Joana LourenÃ§o', '67bcb2cad2e30joana-lourenco.png', '12900', 'omd', 'a:1:{i:0;s:10:\"Endodontia\";}'),
(114, 'Dra. Alina Moscovciuc', '67bcb2f9e4df0alinamosvoc.png', '15054', 'omd', 'a:1:{i:0;s:10:\"Endodontia\";}'),
(115, 'Dra. Madalena Cachopo', '67bcb32bdc5c31510077333_dra.-madalena-cachopo-ntazm46bzmrxy4h6lo4b3y6twev4e004sihap8j0ug.jpg', '1905', 'omd', 'a:1:{i:0;s:27:\"Ortodontia fixa e Removivel\";}'),
(116, 'Dra. InÃªs Quinto', '67bcb378f09f3dra.inesquinto-nxeqi9b94snmisvx20jlklp2hlm3cawav8539j0ft4.png', '10430', 'omd', 'a:1:{i:0;s:27:\"Ortodontia fixa e Removivel\";}'),
(117, 'Dra. Catarina Rocha', '67bcb3a0bcacb1523550020_dramargaridarocha_acl-ntazlldk6y27hx8hnfzrq2xm0pfs41xi1xfl3pawaw.jpg', '9176', 'omd', 'a:1:{i:0;s:27:\"Ortodontia fixa e Removivel\";}'),
(118, 'Dr. JoÃ£o Moreira', '67bcb3c13b774foto_smedico-p10vdn4tzwudjrkubhm7nr8xcj7vps69x7qvl0lvk8.png', '11046', 'omd', 'a:1:{i:0;s:27:\"Ortodontia fixa e Removivel\";}'),
(119, 'Dra. Rita Fernandes', '67bcb3f3f0522ritafernandes.png', '12899', 'omd', 'a:1:{i:0;s:15:\"Odontopediatria\";}'),
(120, 'Dra. Vanessa Rodrigues', '67bcb42ba5c57vanessa_rodrigues.png', '10402', 'omd', 'a:1:{i:0;s:15:\"Periodontologia\";}'),
(121, 'Od. Ester Monteiro', '67bcb4683789d1510156251_od.-ester-monteiro-ntazlhm7flx27hdy9ed9g3vrn5yb99ikpetn6lggzs.jpg', '80586', 'Min. SaÃºde', 'a:1:{i:0;s:22:\"Prostodontia Removivel\";}'),
(122, 'HorÃ¡cio Monteiro', '67bd9cf1e89f0horÃ¡cio.jpg', 'c-014115131', 'acssip', 'a:1:{i:0;s:22:\"Prostodontia Removivel\";}'),
(123, 'Dr. Rui Carvalho', '67bd9d5f6c2ca1510077693_dr.-rui-carvalho-ntazlwnmgyhnd8s3tkvak0355bw6of6a3h9ev0u688.jpg', '6656', 'omd', 'a:1:{i:0;s:13:\"Cirurgia Oral\";}'),
(124, 'Hig. Helena Amaral', '67bd9f0a08ef31521414073_highelenaamaral-ntaznbewq0f4s6qdl6t5ana184y082rsaghmryqww8.jpg', 'c-013060082', 'acss', 'a:1:{i:0;s:12:\"Higiene Oral\";}'),
(125, 'Hig. Suzana Isidro', '67bd9f5cd19a7susana-isidro-pd71im9jbont3o7hch7zmhyi83bg35n8bonthlm77s.png', 'c-069274088', 'acss', 'a:1:{i:0;s:12:\"Higiene Oral\";}'),
(126, 'Hig. Ana Moreira', '67bd9fc193117ana.moreira.png', 'c-073752088', 'acss', 'a:1:{i:0;s:12:\"Higiene Oral\";}'),
(127, 'Hig. Ana Costa', '67bd9fe8d5382ana.costa.png', 'c-073750085', 'acss', 'a:1:{i:0;s:12:\"Higiene Oral\";}'),
(128, 'Hig. Ana Rebocho', '67bda0100758bfoto_smedico-p10vdn4tzwudjrkubhm7nr8xcj7vps69x7qvl0lvk8.png', 'c-075579081', 'acss', 'a:1:{i:0;s:12:\"Higiene Oral\";}');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbutilizadores`
--

CREATE TABLE `tbutilizadores` (
  `id` int(10) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `email` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `tipo` int(1) NOT NULL DEFAULT 2
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tbutilizadores`
--

INSERT INTO `tbutilizadores` (`id`, `nome`, `email`, `password`, `tipo`) VALUES
(1, 'Edson', 'estagio.genium@gmail.com', '1234', 2),
(2, 'Edson', 'estagio.genium@gmail.com', '1234', 2),
(3, 'edson', 'genium.estagio@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 1),
(4, 'Edson', 'marciozinn13@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 2);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `profissionais`
--
ALTER TABLE `profissionais`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tbutilizadores`
--
ALTER TABLE `tbutilizadores`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `profissionais`
--
ALTER TABLE `profissionais`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT de tabela `tbutilizadores`
--
ALTER TABLE `tbutilizadores`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
