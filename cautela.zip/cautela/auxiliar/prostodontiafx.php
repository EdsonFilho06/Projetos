<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="../css/index.css" rel="stylesheet">
    </head>
    <body>
        <h4>Prostodontia Fixa</h4>
        <div class="col-lg-5 col-sm-12 mx auto grid">
            <?php
            require_once('../inc/basedados.php');

            $sql = "SELECT * FROM profissionais WHERE area LIKE '%Prostodontia Fixa%' ORDER BY id";
            $registosDevolvidos = mysqli_query($ligacaodb, $sql);
            while ($linha = mysqli_fetch_assoc($registosDevolvidos)) {
                $nome = $linha["nome"];
                $numero = $linha["numero"];
                $posicao = $linha["posicao"];
                $area = $linha["area"];
                $nomeFicheiro = $linha["foto"];

                echo "
                        <article>
                            <img alt='foto' src='../img/$nomeFicheiro'>
                            <p>$nome</p><br>
                            <b>$numero $posicao</b>
                        </article>
                        ";
            }
            ?>
        </div>
    </body>
</html>