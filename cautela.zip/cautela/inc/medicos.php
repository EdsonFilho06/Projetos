<!DOCTYPE html> 
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <link href="../css/index.css" rel="stylesheet">
    <script src="../js/javascript.js"></script>
    <script>
        function confirmarExclusao(nome, id) {
            if (confirm('Tem certeza que deseja excluir ' + nome + '?')) {
                window.location.href = 'index.php?key=' + id;
            }
        }
        
        function editarProfissional(id) {
            window.location.href = 'editar.php?id=' + id;
        }
    </script>
</head>

<body>
    <h2><b>Gerência dos Médicos</b></h2>
    <div class="col-lg-4 grid">
        <?php
        require_once("basedados.php");
        
        // Excluir registro
        if (isset($_GET["key"]) && $_GET["key"] > 0) {
            $key = $_GET["key"];
            mysqli_query($ligacaodb, "DELETE FROM profissionais WHERE id = $key");
        }
        
        $sql = "SELECT * FROM profissionais ORDER BY id";
        $registosDevolvidos = mysqli_query($ligacaodb, $sql);
        
        while ($linha = mysqli_fetch_assoc($registosDevolvidos)) {
            $id = $linha["id"];
            $nome = $linha['nome'];
            $numero = $linha['numero'];
            $posicao = $linha['posicao'];
            $area = $linha['area'];
            $nomeFicheiro = $linha['foto'];
            
            echo "
                <article>
                    <img alt='foto' src='../img/$nomeFicheiro'>
                    <p>$nome</p>
                    <b>$numero $posicao</b>
                    <p>
                        <button onclick=\"confirmarExclusao('$nome', $id)\">Excluir</button>
                        <button onclick=\"editarProfissional($id)\">Editar</button>
                    </p>
                </article>
            ";
        }
        ?>
    </div>
</body>
</html>
