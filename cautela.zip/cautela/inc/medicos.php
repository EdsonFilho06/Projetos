<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <link href="../css/index.css" rel="stylesheet">
    <script src="../js/javascript.js"></script>
</head>

<body>
    <h2><b>Gerência dos Médicos</b></h2>
    <div class="col-lg-4 grid">
        <?php
        //buscar dados na base de dados ordenador pelo nome
        require_once("basedados.php");
        if (isset($_GET["key"]) && $_GET["key"] > 0) {
            $key = $_GET["key"];
            mysqli_query($ligacaodb, 
            "DELETE FROM profissionais WHERE id = $key");
        }
        $sql = "SELECT * FROM profissionais ORDER BY id";
        $registosDevolvidos = mysqli_query($ligacaodb, $sql);
        while ($linha = mysqli_fetch_assoc($registosDevolvidos)) {
            $nome = $linha['nome'];
            $numero = $linha['numero'];
            $posicao = $linha['posicao'];
            $area = $linha['area'];
            $nomeFicheiro = $linha['foto'];
            $id = $linha["id"]; 
            //imprime os dados no ecra
            echo "
                        <article>
                            <img alt='foto' src='../img/$nomeFicheiro'>
                            <p>$nome</p><br>
                            <b>$numero $posicao</b>
                            <p><a oneclick=\"return confirmar('$nome')\"
                            href='index.php?key=$id'>Eliminar</a></p>
                        </article>
                    ";
        }
        ?>
</body>
</html>