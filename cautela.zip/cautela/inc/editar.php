<?php
require_once("basedados.php");

// Verifica se um ID foi passado via GET
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID inválido.");
}

$id = $_GET['id'];

// Busca os dados do profissional na base
$sql = "SELECT * FROM profissionais WHERE id = $id";
$resultado = mysqli_query($ligacaodb, $sql);
$profissional = mysqli_fetch_assoc($resultado);

if (!$profissional) {
    die("Profissional não encontrado.");
}

// Atualiza os dados na base de dados ao enviar o formulário
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $numero = $_POST['numero'];
    $posicao = $_POST['posicao'];
    $area = $_POST['area'];

    $sqlUpdate = "UPDATE profissionais SET 
                    nome='$nome', 
                    numero='$numero', 
                    posicao='$posicao', 
                    area='$area' 
                WHERE id=$id";

    if (mysqli_query($ligacaodb, $sqlUpdate)) {
        echo "<script>alert('Dados atualizados com sucesso!'); window.location.href='index.php';</script>";
    } else {
        echo "Erro ao atualizar os dados: " . mysqli_error($ligacaodb);
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <link href="../css/index.css" rel="stylesheet">
</head>
<body>
    <h2>Editar Profissional</h2>
    <form method="POST">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?php echo $profissional['nome']; ?>" required>

        <label>Número:</label>
        <input type="text" name="numero" value="<?php echo $profissional['numero']; ?>" required>

        <label>Posição:</label>
        <input type="text" name="posicao" value="<?php echo $profissional['posicao']; ?>" required>

        <label>Área:</label>
        <input type="text" name="area" value="<?php echo $profissional['area']; ?>" required>

        <button type="submit">Salvar Alterações</button>
        <a href="index.php"><button type="button">Cancelar</button></a>
    </form>
</body>
</html>
