<?php 
    $host = "localhost";
    $user = "root";
    $pass = "";
    $bd = "cautela";
    
    $ligacaodb = mysqli_connect($host, $user, $pass, $bd);
    $sql = "ANALYZE TABLE `profissionais`;";
    $sql = "OPTIMIZE TABLE `profissionais`;";
?>