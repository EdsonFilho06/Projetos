<?php
session_start();
//verificar se o ficheiro foi submetido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST["email"];
    $password = md5($_POST["password"]);

    //incluir ligação a base de dados
    require_once('../inc/Medoo.php');

    //verificar se existe alguma linha com nome email e password
    $usuario = $basedados->get("tbutilizadores",
        "*",
        [
            "email" => $email,
            "password" => $password,
        ]);

        //verificar se dados de acesso estão corretos
        if ($usuario){
            $_SESSION['autenticado'] = true;
            $_SESSION['nomeUtilizador'] = $usuario['nome'];
            $_SESSION['tipoUtilizador'] = $usuario['tipo'];
            $_SESSION['passwordUtilizador'] = $usuario['password'];
            $_SESSION['emailUtilizador'] = $usuario['email'];

            //redireccionar para a página inicial
            header('location: formulario.php');
        } else {
            echo "<script>alert('Dados de acesso inválidos!')</script>";
        }
}
?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta namr="viewport" content="width=device-width, initial-scale=1">
    <title>Página de Login</title>
    <link href="../css/login.css" rel="stylesheet">
</head>

<body>
    <main>
        <main class="container-fluid">
            <form class="text-center mt-4" method="post" action="" enctype="multipart/form-data">
                <h2>Faça Login</h2>
                <p>
                    <br>
                    <br>
                    <label for="nome">Nome: </label>
                    <input type="text" id="name" name="nome" required>
                </p>
                <p>
                    <label for="email">Email: </label>
                    <input type="email" id="email" name="email" required>
                </p>
                <p>
                    <label for="password">Senha: </label>
                    <input type="password" id="password" name="password" required>
                </p>
                <p>
                    <input type="submit" value="Logar" id="enviar">
                </p>
            </form>
        </main>
</body>

</html>