<?php
    //terminar sessão
    session_start();

    session_destroy();
    //redirecionar para a página principal
    header("Location: index.php");
?>