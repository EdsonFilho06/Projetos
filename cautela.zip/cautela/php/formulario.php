<?php 
session_start();
if (isset($_SESSION["autenticado"])){
    header("location: login.php");
    exit;
}

//verificar se o ficheiro  foi submetido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    //recuperar dados do formulário
    $nome = $_POST["nome"];
    $numero = $_POST["numero"];
    $posicao = $_POST["posicao"];
    $area = $_POST["area"];

    //upload de ficheiros para o site
    $nomeFicheiro = uniqid() . $_FILES['foto']['name'];
    move_uploaded_file($_FILES['foto']['tmp_name'], "../img/" . $nomeFicheiro);

    //incluir ligação a base de dados
    require_once('../inc/Medoo.php');

    //inserir dados na base dde dados
    $basedados->insert("profissionais", [
        "nome" => $nome,
        "numero" => $numero,
        "posicao" => $posicao,
        "area" => $area,
        "foto" => $nomeFicheiro
    ]);
    //verificar se INSERT foi feito com sucesso
    if ($basedados->id() > 0) {
        echo "<script>alert('Inserido com Sucesso!')</script>";
    } else {
        echo "<script>alert('Ocorreu um erro!')</script>";
    }
    }
    // Conexão com o banco de dados
    $mysqli = new mysqli("localhost", "root", "", "cautela");

    if ($mysqli->connect_error) {
        die("Falha na conexão: " . $mysqli->connect_error);
    }

    // Recuperar os valores do formulário (checkboxes)
    $areas_selecionadas = isset($_POST['area']) ? $_POST['area'] : [];

    // Converter a lista de áreas selecionadas em uma string separada por vírgulas
    $novas_areas = implode(" , ", $areas_selecionadas);

    // ID do profissional (Exemplo: id=1)
    $id_profissional = 0;  // Este valor pode ser obtido de algum outro lugar, como da URL ou sessão

    // Recuperar as áreas já existentes
    $sql = "SELECT area FROM profissionais WHERE id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $id_profissional);
    $stmt->execute();
    $stmt->bind_result($areas_existentes);
    $stmt->fetch();
    $stmt->close();

    // Concatenar as áreas existentes com as novas áreas selecionadas
    if ($areas_existentes) {
        // Se já existirem valores, apenas concatena, garantindo que não tenha vírgula extra no início
        $area_final = $areas_existentes . ", " . $novas_areas;
    } else {
        // Se não houver valores, simplesmente usa as áreas selecionadas
        $area_final = $novas_areas;
    }

    // Atualizar a tabela com o novo valor
    $sql_update = "UPDATE profissionais SET area = ? WHERE id = ?";
    $stmt_update = $mysqli->prepare($sql_update);
    $stmt_update->bind_param("si", $area_final, $id_profissional);
    $stmt_update->execute();
    $stmt_update->close();

    // Fechar a conexão
    $mysqli->close();
    ?>


<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="widht=device-width, initial-scale=1">
    <title>form</title>
    <link href="../css/formulario.css" rel="stylesheet">
</head>

<body>
    <!-- formulario para adicionar novo funcionario na base de dados -->
    <main class="container-fluid">
        <?php if(isset($_SESSION['autenticado'])){?>
        <form class="text-center mt-4" method="post" action="" enctype="multipart/form-data">
            <p>
                <br>
                <br>
                <!-- adicionar nome do médico novo-->
                <label for="nome">Nome: </label>
                <input type="text" id="name" name="nome" placeholder="Ex: Dr. Joao" required>
            </p>
            <p>
                <label for="numero">Número: </label>
                <input type="text" id="numero" name="numero" placeholder="Ex: 101239" required>
            </p>
            <p>
                <label for="posicao">Posição: </label>
                <input type="text" id="posicao" name="posicao" placeholder="Ex: OMD" required>
            </p>
            <p required>
                <label for="area">Área de atuacao:<br> </label>
                <input type="checkbox" id="area" name="area[]" value="Gerencia">
                <label for="area"> Gerência</label><br>
                <input type="checkbox" id="area" name="area[]" value="Prostodontia Fixa">
                <label for="area"> Prostodontia Fixa</label><br>
                <input type="checkbox" id="area" name="area[]" value="Generalista">
                <label for="area"> Generalista</label><br>
                <input type="checkbox" id="area" name="area[]" value="Endodontia">
                <label for="area"> Endodontia</label><br>
                <input type="checkbox" id="area" name="area[]" value="Ortodontia fixa e Removivel">
                <label for="area"> Ortodontia Fixa e Removível</label><br>
                <input type="checkbox" id="area" name="area[]" value="Implantologia">
                <label for="area"> Implantologia</label><br>
                <input type="checkbox" id="area" name="area[]" value="Odontopediatria">
                <label for="area"> Odontopediatria</label><br>
                <input type="checkbox" id="area" name="area[]" value="Periodontologia">
                <label for="area"> Periodontologia</label><br>
                <input type="checkbox" id="area" name="area[]" value="Prostodontia Removivel">
                <label for="area"> Prostodontia Removível</label><br>
                <input type="checkbox" id="area" name="area[]" value="Cirurgia Oral">
                <label for="area"> Cirurgia Oral</label><br>
                <input type="checkbox" id="area" name="area[]" value="Oclusao">
                <label for="area"> Oclusão</label><br>
                <input type="checkbox" id="area" name="area[]" value="Higiene Oral">
                <label for="area"> Higiene Oral</label><br>
            </p>
            <p>
                <label for="foto">Foto: </label>
                <input type="file" id="foto" name="foto" required>
            </p>
            <!-- submete todos os dados colhidos diretamente para a bd-->
            <div class="botoes">
                
                <p>
                    <input type="submit" id="enviar" value="Inserir profissional">
                </p>
                <?php }?>
                <p>
                    <button><a href="index.php">Página principal</a></button>
                </p>
                <?php if(isset($_SESSION['autenticado']) && $_SESSION['tipo'] === 1){ // se for administrador?>
                <p>
                    <button><a href="../inc/medicos.php">Planilha dos medicos</a></button>
                </p>
                <?php }?>
                <p>
                    <button><a href="logout.php">Logout</a></button>
                </p>
            </div>
        </form>
    </main>
</body>
</html>