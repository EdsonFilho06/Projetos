<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Clinica Cautela</title>
    <link href="../css/index.css" rel="stylesheet">
    <link href="../css/ho.css" rel="stylesheet">
</head>

<body>
    <main class="container-fluid">
        <!-- banner do site -->
        <header class="row">
            <div class="col-lg-12 banner">
                <img src="../img/logo.png" alt="logo" width=280 height=85>
            </div>
        </header>
        </div>
        <div class="ladoalado">
            <div class="a">
                <?php require_once("../auxiliar/gerencia.php"); ?>
            </div>
            <div class="b">
                <?php require_once("../auxiliar/prostodontiafx.php"); ?>
            </div>
        </div>
        <?php
        require_once("../auxiliar/generalista.php");
        require_once("../auxiliar/endodontia.php");
        require_once("../auxiliar/ortodontiafxrm.php");
        require_once("../auxiliar/implantologia.php");
        ?>
        <div class="ladolado">
            <div class="c">
                <?php require_once("../auxiliar/odontopediatria.php"); ?>
            </div>
            <div class="d">
                <?php require_once("../auxiliar/periodontologia.php"); ?>
            </div>
        </div>
        <?php
            require_once("../auxiliar/prostodontiarm.php");
            require_once("../auxiliar/cirurgiaoral.php");
            require_once("../auxiliar/oclusao.php");
        ?>
        <div class="e">
            <?php require_once("../auxiliar/higieneoral.php"); ?>
        </div>
        
        <div class="fixado">
            <?php require_once('../html/patrocinios.html') ?>
        </div>
    </main>
</body>

</html>