<?php
session_start();

//variável auxiliar
$msg = "";

//verificar se o ficheiro foi submetido
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    //incluir ligação a base de dados
    require_once('../inc/Medoo.php');

    //verificar se já existe um utilizador registado com o email digitado no registado
    $emailexistente = $basedados->get(
        "tbutilizadores",
        "*",
        ["email" => $email]
    );

    if($emailexistente) {
        $msg = "<p style='color: red'>Já existe um utilizador registado com este email'$email'!</p>";
    } else {
        //verificar se existe alguma linha com email e password
        $basedados->insert("tbutilizadores", [
            "nome"=> $nome,
            "email"=> $email,
            "password"=> $password,
            "tipo" => 2
        ]);
        $msg = "<p style='green: red'>Conta criada com sucesso</p>";
        header("location: login.php");
    }
}
?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta namr="viewport" content="width=device-width, initial-scale=1">
    <title>Página de Login</title>
    <link href="../css/login.css" rel="stylesheet">
</head>

<body>
    <main>
        <main class="container-fluid">
            <form class="text-center mt-4" method="post" action="" enctype="multipart/form-data">
                <h2>Registre-se</h2>
                <p>
                    <br>
                    <br>
                    <label for="nome">Nome: </label>
                    <input type="text" id="name" name="nome" required>
                </p>
                <p>
                    <label for="email">Email: </label>
                    <input type="email" id="email" name="email" required>
                </p>
                <p>
                    <label for="password">Senha: </label>
                    <input type="password" id="password" name="password" required>
                </p>
                <p>
                    <input type="submit" value="Registar" id="enviar">
                </p>
            </form>
        </main>
</body>

</html>