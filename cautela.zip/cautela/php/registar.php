<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta namr="viewport" content="width=device-width, initial-scale=1">
    <title>Página de Login</title>
    <link href="../css/index.css" rel="stylesheet">
</head>

<body>
    <main>
        <main class="container-fluid">
            <form class="text-center mt-4" method="post" action="" enctype="multipart/form-data">
                <p>
                    <br>
                    <br>
                    <!-- adicionar nome do médico novo-->
                    <label for="nome">Nome: </label>
                    <input type="text" id="name" name="nome" required>
                </p>
                <p>
                    <label for="email">Email: </label>
                    <input type="email" id="email" name="email" required>
                </p>
                <p>
                    <label for="password">Senha: </label>
                    <input type="password" id="password" name="password" required>
                </p>
                <p>
                    <input type="submit" value="Refistar" id="enviar">
                </p>
            </form>
        </main>
</body>

</html>