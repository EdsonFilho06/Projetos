function confirmarExclusao(nome, id) {
    if (confirm('Tem certeza que deseja excluir ' + nome + '?')) {
        // Criar um formulário oculto e enviá-lo via POST
        let form = document.createElement('form');
        form.method = 'POST';
        form.action = 'medicos.php';
        
        let input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'delete_id';
        input.value = id;
        
        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
    }
}

function editarProfissional(id) {
    window.location.href = 'editar.php?id=' + id;
}