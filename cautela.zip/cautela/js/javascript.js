function confirmarExclusao(nome, id) {
    if (confirm('Tem certeza que deseja excluir ' + nome + '?')) {
        window.location.href = 'index.php?key=' + id;
    }
}