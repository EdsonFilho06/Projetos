function confirmar(){
    if(confirm("Tens a certeza que deseja apagar o ' " + nome +" '")){
        return true;
    }else{
        return false;
    }
}
